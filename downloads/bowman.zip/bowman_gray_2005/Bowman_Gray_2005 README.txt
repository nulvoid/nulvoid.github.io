
Bowman-Gray Stadium (2005 Night version)
Bowman-Gray 2005 (Night)
Short Track (0.25 Miles)

[ To read this file, select Format/Word Wrap from the menu above ]

TABLE OF CONTENTS:

[1] HOW TO INSTALL THE TRACK
[2] GENERAL TRACK INFORMATION
[3] PROJECT DEVELOPMENT AND CREDITS
[4] KNOWN ISSUES  
[5] TROUBLE REPORTING
[6] DISTRIBUTION INFORMATION
[7] AGREEMENT OF USE

--------------------------------------------------------------------------------


[1] HOW TO INSTALL THE TRACK
====================================

Unzip the zip file. The default location is C:\Papyrus\Nascar Racing 2003 Season\tracks\. If you have multiple instances of NR2003S installed, you will need to manually select the tracks directory where you wish to install the track.

[2] GENERAL TRACK INFORMATION
====================================

Type: Real track

AI: Yes.  Working pit stalls for 29 total cars (28 opponents)

Mod support: GNS,CTS. (This track was not tested using any other physics other than those listed.)

Track Information: approx. 1/4 mile flat asphalt oval in Winston-Salem, NC. Hosts National Touring events for the Whelen Southern Modified Tour. Also runs weekly NASCAR sanctioned racing programs including Modifieds, Sportsman, Street Stocks and Stadium Stocks.  

This NR2003 version is an attempt to closely resemble the track as it appeared in 2005.  It is not, however, an exact replica nor do the limits of NR2003 allow it to be.  A new fieldhouse has been constructed at the real track in 2007.  This version features the fieldhouse that was at the track for many years through 2005.  After which it was torn down to construct a new fieldhouse facility that went up in 2007.  Because the track is approximately .250 miles in length, it presented many challanges to get to work properly in NR2003.  A full 200 lap race can be run on the same set of tires and with a full tank of fuel.  It is intentionally constructed to not require pit stops for tires and/or fuel.  Further, it goes without saying that if you decide to pit during caution or green flag racing you will not be able to remain on the lead lap.

The GNS track grip is set well to run the Modifieds and I think that you'll find one of the default setups that are included with the track to be of your liking.  The AI are very tough to pass, so get ready for some door bangin' wheel-to-wheel  action.  You may find that you'll have to "nudge" 'em a little going into the corner by "Givin' 'Em the Crome Horn" in order to get around them.  But after all is said and done, the track is a flatout blast to race on.

There will also be a 1970 version released soon.  



[3] PROJECT DEVELOPMENT AND CREDITS
====================================

This project truly represents a collaboration of the talents and skills of a number of the best track builders in the NR2003 sim community.  This, my friends, is what it is all about and gives the term "Community" great meaning.  Their names and individual contributions to this track are detailed below.  But first a little history of how this all came about.

In December of 2005, Raybee1970 contacted me about working on a more accurate version of Bowman-Gray Stadium (BGS) for NR2003. I had always been interested in having this particuliar track for NR2003.  Especially one that would feature working AI and could be enjoyed for both offline and online use.  We were determined to try to produce one of the most realistic looking tracks ever made for NR20003 and one that people who have been to the real Bowman-Gray Stadium would agree looked authentic.  Whether or not we were successful rests with each you.  There is so much more to this story that I could tell you, but you've probably stopped reading by now anyway.  LOL

So here it is.  A culmination of work nearly 2 years in the making.  I sincerely hope that you all enjoy it!

J.R. Franklin
     

Additional Credits:

The following is a list of the people who helped me with this project.  It reads like a "Who's Who" of NR2003 track builders. I owe a debt of gratitude to each of you for your contributions, friendship, time and help:

1.  Raybee1970:  Detailing, project development and consultation
2.  SteveB:  AI help, pit layout, pacecar  (If you like the AI, let me know.  If you don't, contact SteveB.) LOL jk ;-)
3.  Omodified:  Billboards, Scorboards, misc graphics, pit layout consultation  
4.  Riviera71:  Cameras (Also special thanks to Carl for teaching me how to make cams.)
5.  Denis Rioux:  3d crowds for stadium, misc. objects, turn 4 Winston-Salem skyscrapers in horizon, quality control
6.  Wayne "Bowtie" Anderson: Bowman-Gray Tower object and attached platforms
7.  Danny Coral:  Default Fast and Expert setups for GNS and CTS physics.
8.  WayBar Racing (aka Wayne Faircloth and Terry O'Bar):  'WayBar_BGS2005_Race' setups for both GNS and CTS physics.  
9.  Midnight Wrangler:  camera help
10. FFSBudman:  creator of Bowman-Gray for NASCAR Heat and who allowed some of his hand-made objects to be used for this NR2003 version.
11. Tyler Brunkhorst:  Who originally started Bowman-Gray for NASCAR Heat and who created the main stadium and field house objects.
12. All of the guys in the forums at NR2k3tracks.com, DesignsByRioux.com and The ModSquad for their support.
13. Beta Testers:  All of the above, plus Jim Foose, Mark Royer, Draftdancer, RHamm, Oldasdirt (OAD), Robert Vining, Chadley, Bill Anderson and Mike Akai.
14. Anyone else whom I neglicted to mention but contributed in the creation of objects, etc. I may have borrowed from other NR2003 tracks, I apologize.  Although you were not mentioned individually, your contributions to NR2003 are greatly appreciated.

Long Live NR2003!
 

[4] KNOWN ISSUES
==================================== 

1.  Pacing under caution.  Due to the very small (approx. 1/4 mile) configuration of this track, the AI cars have a tendancy to slow down significantly at each end of the track during caution pacing.  This can be observed even more dramatically in a race where AI cars have sustained damage, are laps down to the leader and/or are pitting.  Much effort has been spent in trying to eliminate this problem, but it is likely not fixable.  Instead, it is a problem commonly found in other NR2003 tracks of such small configuration and with the added complication of having the pits located in turns 3 and 4.

2.  Regrouping after caution.  For the same reasons as stated above, the field may exhibit difficulty in getting realigned behind the pacecar after a caution flies.  However, while it may take an extra lap or 2 after the caution flag is displayed, testing has shown that the field will eventually get properly lined back up before green flag racing resumes.

3.  Pitting.  a.) Because of the location of the pits and the related pit Lp lines that the AI cars must follow, there are segments of pit road where the pit Lps are almost perpendiculiar to the track's centerline.  This causes some difficulty in setting the values in the track.ini to get the AI cars to pull into and out of their respective pit stalls smoothly with proper approach and departure angles.  AI cars will appear to be "pulled" into their stalls.  They pit fine, but do not always look great doing it.  Pit Lps should, for the most part, be parallel to the centerline to work properly, so we have pushed the 'envelope' of NR2003 with this pit configuration.  b.) Due to the configuartion of the track and pits, it is impossible to remain on the lead lap while performing any type of routine pit stop.  c.)  Occasionally, AI cars will "brush" or "clip" the armco fencing when they depart pit road.  Especially noticeable when several cars are exiting at the same time.  d.) After the checkered flag has waved at the race has ended, all of the AI cars stack up along the backstretch as they drive back to their respective pit stalls.  On their way back, several AI cars will cut across the inside of the orange cones on the left at the entry of pit road.  This seems to be the only time this particuliar bug is observed and does not affect the racing in any way.

4.  Slow draw-in of buildings and horizons.  The buildings behind turns 3 and 4 exhibit a slow draw-in problem.  I suspect that it is a result of the location of the objects in relation to the track.  I have found with my PC that the problem is more noticeable with some mods than it is with the other mods and seems to be most evident when driving with the roof cam.  Other testers have found that the problem exists with all of the mods.  So I guess that the severity of the problem will depend upon the PC you have and how you have your game configured. 

5.  This track was not tested with CUP or PTA physics.  All testing and track.ini settings are for the GNS and CTS physics which the authors of the track feel are best suited to racing at Bowman-Gray Stadium.  The CUP physics will work, but the AI has not been balanced in CUP. 


[5] TROUBLE REPORTING 
====================================

This track is not supported by or affiliated with Vivendi Universal Games, Sierra Online, or Papyrus Racing Games so please do not call or email.

You may use the forums at www.NR2k3Tracks.com for questions regarding the track.


[6] DISTRIBUTION INFORMATION 
====================================

Distributing Websites:

www.nr2k3tracks.com
http://themodsquad.uni.cc

THIS TRACK SHALL NOT BE POSTED AT ANY WEBSITES, OTHER THAN THE ONES PROVIDED, WITHOUT PRIOR WRITTEN PERMISSION FROM J.R. Franklin and Raybee1970.  To obtain permission to post, please PM J.R.Franklin at www.NR2k3Tracks.com and Raybee1970 at http://themodsquad.uni.cc.  


[7] AGREEMENT OF USE
=====================================

Use of this track by installation into a racing simulator constitutes agreement with this and the following statements:

1) This track shall not be sold or distributed for commercial purposes, or money 
exchanged for this track or any part thereof.

2) This track shall not be redistributed without written consent of the original 
author, with exception of the sites listed above. 

3) This track cannot be modifed without written consent of the original author.

4) This track, nor any parts thereof, shall not be converted to rFactor or any other simulation without the signed written consent of J.R. Franklin and Raybee1970.

5) This track must always maintain an unmodified copy of this readme in whatever form it
is distributed.

6) This track is covered by implied intellectual property laws, in that it is the property
of the author.

7) This track is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.