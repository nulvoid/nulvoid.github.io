SOBO_2007 Release 3/27/07

Special Thanks to Denis Rioux for allowing us to revamp his Track.

Credits, and Thanks to:

Mark Royer(STProcup.com)-Outer Facility Fence, and Various .3do work

Chris O'Shell(ASTG)- Scoreboard, and Big Sign .3do's, and the use of many of his Infield trucks, and Supplying me with several Fonts.

Joshua Guiher(Butter)- for making a new hole in the wall for outside pit access, Helping me find several bad track sections to fix..
cleaning up the Track .ini..and most of all.. 
every day consultation, and explaining things to me in terms a gorilla could understand!

Rob Reiter(GRN357) - Track Cameras

Wayne Anderson (Bowtie)- the use of his small bleachers, and people.

Carl Sundberg(ASTG)- for finding just one last pestering segment in turn 4 that caused BF issues.

Danny Coral Track Surface, grip, GNS, CTS, and Modified Setups. also Billboards, scoreboard, TSO's, and Grandstand paintjob.


Also Huge thanks once again to Denis Rioux (Dakota Sim) ,as we tried to leave much of his original work untouched.

*This track could not have been finished without any of the guys listed above.*



Thanks to All the Track Testers

Carl Sundberg
Josh Guiher (won first ever league race on it)
Wayne Faircloth
John Turnure
Keith Pierce
Adam Fohlin
Brett Clary
Rob Reiter
Mike Woodring
Darryl Matlock
Scooter Bryant
Philly Howard
Terry O'Bar
Rex Hoyle
Kevin Kelleher
Doug Beasley



Known Issues: None...use your head in 3, and 4...
those barrels are there for a reason get below them while racing,
there is a good chance you will need to serve a penalty.

This track may only be hosted at BullRing MotorSports, and FSD SimRacing, and SimFans.net

This Track is For Sim Racing, please do not try to drive your real car on it..





