Trackname: waterford speedbowl	wcr	
Version: 1 
Year of creation: 2005
Racing sim: NASCAR Racing 2003
Author(s):Scott Dillner
Email(s):sdill20138@aol.com or sticky@windycityracing.com

--------------------------------------------------------------------------------
Type: real

Waterford Speedbowl opened its doors as New London Speedway on Sunday, April 15, 1951. Bob Swift found the quickest way around on the crushed blue stone surface to go down in history as the first winner. The first event was preceded by a "Preview Practice Session" that drew 8,000 and caused traffic jams on Route 85.
After three events on the original surface - the dust problem was terrible - the track was paved. Now called New London-Waterford Speedbowl, the track took its place on a racing horizon that was filled with tracks, almost all of which are now gone.
Hall of Famer Dave Humphrey captured the first championship by a slim two points over Moe "Moneybags' Gherzi, setting in motion a continuum of close competition that still exists on the three-eighths oval.
From Humphrey to present champion Dennis Gada, the sport's legendary names have taken on the challenging oval in both stock cars and open-wheel machines. Johnny Thomson, considered New England's greatest open-cockpit driver, was a two-time winner at the Speedbowl in 1951.
Earlier this year, Eric Berndt's $8,027 first-place money at the Modified Nationals was a record for the SK-Modified division. Last season, Phil Rondeau became the first competitor to go over the 100 win in a single division (Late Models).Dennis Gada is the third straight driver to join his father on the championships list.

That tradition continues as the Speedbowl, now a proud member of the NASCAR Weekly Racing Series, presents not only outstanding weekly action but hosts the area's top touring divisions as well. The Speedbowl's list of Modified champions rivals that of any track. 

_________________________________________________________________________________________________________________________________________________

Installation: just unzip or copy the waterford directory to the tracks directory in your papyrus/ nascar 2003 season folder



++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

notes:


. If you downloaded the track from some other site than www.windycityracing.com, or 3331234.com then some dumb  crotch gobbler has posted the track on his own stoopid website in violation of this license, You most likely do not have the newest version, so go to windycityracing.com and get the current version and leave the crotch gobbler to gobble crotches, he cant help it that his  mommy is easy. ha


+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Bugs
1 ai has pitting issues sometimes, they hit the wall going in, the first couple pit stalls hit the wall comming out too, if you know why tell me and i will fix it
2. ai slowsdown comming out of the corners a tad
3. bumps in the turns..the track looks bumpy fromthe photos
4 ai dogpiles into the pits at race end
5 times are about one second faster than at the real track
6. the defualt setups are ok, but are not the best
7. a few of the camera angles are off
8. dont get too close the the outside wall exiting pits
9. Please report any bugs to sticky@windycityracing.com or just thanklessly bitch, whine, complain and nitpick my free f'ing work 

10 at the end of the race look at the flagman....dont listen to your spotter, he will tell you there is one to go when there is two to go


11 sorry no easter eggs in this one

12 no arcade setups so track will not load in arcade mode unless you add some yourself

13 there are pta settings and setups but not a lot of testing was done with the pta mod

14 no warmup lap for qualify, also dont speed in the pits when qualifying

15 beacuse of the outside pit location, you most likely will go a lap down when pitting under yellow, the pit road speed is a bit fast, 50mph to try to get around this.

16 The pits apparently are not used at the real track during green flag racing so the pit entrance isnt entirely accurate

enjoy!

Scott

___________________________________________________________________________________________________________________________
Credits and thanks

-stefanodimera72-- testing, review, stp files, graphics, signs, setups, AI.... and much much more...thanks man!
-papy...game and sandbox and 3do's
-the gents that made the winmip program, mip editor, camera editor and dat compiler
-The helpful souls that frequent the scr and pits forums

_wcr...testing....and beer
- stefandinera, harvick2win, woobie,champkarter1, steveb73, J.R., MADDOG_RACER,roushman31,Raybee1970,                 mike rainville  beta testing
-jr   3dos, track help and testing
-stevee b  ai consultation
_Charlieman52....pics and testing

-dave noonan....3do's and 3do program's


-any any one else I forgot
-racefans and sim race fans alike
-ALL LOGOS ARE THE PROPERTY OF THEIR OWNERS


PLEASE NOTE: I borrowed many many 3do's from other tracks and made every attempt to contact the original author for permission to include them in this track, if by chance I didnt contact you and you object to me using your mip or 3do in this track contact me at scott@windycityracing.com and I remove the files immediately. It would be greatly appreciated if you would contact me prior to using any of the 3do's from this track. 




Enjoy!!


scott/sticky22
www.windycityracing.com........






--------------------------------------------------------------------------------
			    Installation: just unzip or copy the waterford directory to the tracks directory in your papyrus/ nascar 2003 season folder



++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

notes:


. If you downloaded the track from some other site than www.windycityracing.com, or 3331234.com then some dumb  crotch gobbler has posted the track on his own stoopid website in violation of this license, You most likely do not have the newest version, so go to windycityracing.com and get the current version and leave the crotch gobbler to gobble crotches, he cant help it that his  mommy is easy. ha


+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


			    AGREEMENT OF USE....YOU SHOULD CAREFULLY READ THE FOLLOWING END USER LICENSE AGREEMENT BEFORE INSTALLING THIS SOFTWARE track. BY INSTALLING OR OTHERWISE USING THE SOFTWARE track, YOU AGREE TO BE BOUND BY THE TERMS OF THIS AGREEMENT. IF YOU DO NOT AGREE TO THE TERMS OF THIS AGREEMENT, PROMPTLY DELETE THE UNUSED SOFTWARE track

YOU SHOULD CAREFULLY READ THE FOLLOWING END USER LICENSE AGREEMENT BEFORE INSTALLING THIS SOFTWARE track. BY INSTALLING OR OTHERWISE USING THE SOFTWARE track, YOU AGREE TO BE BOUND BY THE TERMS OF THIS AGREEMENT. IF YOU DO NOT AGREE TO THE TERMS OF THIS AGREEMENT, PROMPTLY DELETE THE UNUSED SOFTWARE track


author( the guy that made the track) and user ( the guy that is reading this) agree as follows



Use of this track  constitutes agreement 
with this and the following statements, enjoy my work but please play by the rules:

1) This track may not be sold or distributed for commercial purposes, or money 
exchanged for this track or any part thereof, without the express written consent of the author.

2) This track may not be redistributed without the express written consent of the author. The only authorized distribution point is www.3331234.com, and www.windycityracing.com. It shall not be posted anywhere else without the express written consent of the author.

3) This track may not be modifed without the express written consent of the original author.

4) This track must always maintain an unmodified copy of this readme in whatever form it
is distributed.

5) This track is the property of the author pursuant to express and implied intellectual property laws, and all other applicable statutes.

6) Warranty Disclaimer. THE TRACK IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY KIND AND AUTHOR EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, QUALITY, ACCURACY AND NONINFRINGEMENT OF THIRD PARTY RIGHTS.

7. JURISDICTION AND REMEDIES: User agrees to comply with all applicable laws in its use of the track, including all applicable export control laws. This Agreement is governed by the laws of the United States and the State of Illinois, without reference to conflict of laws principles. The application of the United Nations Convention of Contracts for the International Sale of Goods is expressly excluded. Any dispute between the User and the Author regarding this Agreement will be subject to the exclusive jurisdiction of the state and federal courts in Cook County in the State of Illinois USA. This Agreement is the entire agreement between the User and the Author and supersedes any other communications.  You hereby agree that the author would be irreparably damaged if the terms of this  Agreement were not specifically enforced, and therefore you agree that the author shall be entitled, without bond, other security, or proof of damages, to appropriate and immediate equitable remedies with respect to breaches of this Agreement, in addition to such other remedies as the author may otherwise have available to him under applicable laws. In the event any litigation is brought by author or user in connection with this Agreement, the author in such litigation shall be entitled to recover from the user all the reasonable costs, attorneys� fees and other expenses incurred by author in the litigation. 

8. General. If any provision of this Agreement is held invalid, the remainder of this Agreement will continue in full force and effect. No provision of this Agreement shall be deemed waived or modified except in a writing signed by an authorized representative of the author. There are no implied licenses hereunder. User may not assign this Agreement without the prior written consent of the Author. 





9. This track (the "track"), any printed materials, any on-line or electronic documentation, and any and all copies and derivative or transformative works of such track except included previously coprwrighted or trademarked logos and names are the work and property of AUTHOR,   All rights reserved, except as expressly stated herein.  All use of the track is governed by the terms of this End User License Agreement provided below ("License Agreement"). The track is solely for use by end users according to the terms of the License Agreement. Any use, reproduction or redistribution of the track not in accordance with the terms of the License Agreement is expressly prohibited.

10 Limited Use License. Scott/sticky ("AUTHOR") hereby grants, and by installing the track you thereby accept, a limited, non-exclusive license and right to install and use one (1) copy of the track for your use on either a home, business or portable computer. In addition, the track has a multi-player capability that allows users to utilize the track over the Internet via Sierra�s online game network Sierra.com. Use of the track over Sierra.com is subject to your acceptance of Sierra.com�s Terms of Use Agreement.  The track is licensed, not sold. Your license confers no title or ownership in the track.
	
	
	
	11 Termination. This License Agreement is effective until terminated. You may terminate the License Agreement at any time by destroying the track. Destroying the track does not extinguish any libility, cause of action or the like arising before terminatin. Author,  at its discretion, terminate this License Agreement in the event that you fail to comply with the terms and conditions contained herein. In such event, you must immediately destroy the track. 
	
	12. Export Controls. The track may not be re-exported, downloaded or otherwise exported into (or to a national or resident of) any country to which the U.S. has embargoed goods, or to anyone on the U.S. Treasury Department�s list of Specially Designated Nationals or the U.S. Commerce Department�s Table of Denial Orders. By installing the track, you are agreeing to the foregoing and you are representing and warranting that you are not located in, under the control of, or a national or resident of any such country or on any such list.
	
	

	
	13. Equitable Remedies. You hereby agree that author would be irreparably damaged if the terms of this License Agreement were not specifically enforced, and therefore you agree that authorshall be entitled, without bond, other security, or proof of damages, to appropriate equitable remedies with respect to breaches of this License Agreement, in addition to such other remedies as authormay otherwise have available to it under applicable laws. In the event any litigation is brought by either party in connection with this License Agreement, the author  shall be entitled to recover from the other party all the costs, attorneys� fees and other expenses incurred by author in the litigation.


	
	
	14. Miscellaneous. This License Agreement shall be deemed to have been made and executed in the State of Illinois and any dispute arising hereunder shall be resolved in accordance with the law of Illinois. You agree that any claim asserted in any legal proceeding by one of the parties against the other shall be commenced and maintained in any state or federal court located in the State of Illinois, County of Cook, having subject matter jurisdiction with respect to the dispute between the parties. This License Agreement may be amended, altered or modified only by an instrument in writing, specifying such amendment, alteration or modification, executed by both parties. In the event that any provision of this License Agreement shall be held by a court or other tribunal of competent jurisdiction to be unenforceable, such provision will be enforced to the maximum extent permissible and the remaining portions of this License Agreement shall remain in full force and effect. This License Agreement constitutes and contains the entire agreement between the parties with respect to the subject matter hereof and supersedes any prior oral or written agreements.


15 User hereby consents and authorizes any website,discussion board or other online electronic medium where a breach of this agreement is discussed by user, to provide information regarding users personal electronice data including but not limited to name,address, telephone number, ip address and the like, in response to a request by subpoena or otherwise, by author. User hereby waives any and all defenses that he or she may have to such request.


I acknowledge that I have read and understand this License Agreement and agree that the action of installing the track is my agreement to be bound by the terms and conditions of this  Agreement  I am a big boy and when the shit hits the fan I will not whine and cry and blame everyone but my self for my lack of common sense.  I also acknowledge and agree that this License Agreement is the complete and exclusive statement of the agreement between AUTHORand I and that the License Agreement supersedes any prior or contemporaneous agreement, either oral or written, and any other communications between AUTHORand myself. If you do not agree this agreement then dont install the track



Scott 2005