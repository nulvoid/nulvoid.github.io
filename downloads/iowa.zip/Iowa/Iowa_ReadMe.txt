==========================================================
How to Install the Track
==========================================================
Open the zip file an extract to your track folder. The default location is C:\Papyrus\Nascar Racing 2003 Season\tracks\. If you have multiple instances of NR2003S installed, you will need to manually select the directory where you wish to install the track.

==========================================================
Known Issues
==========================================================
None the we know of.

==========================================================
Trouble Reporting 
==========================================================
Iowa Speedway Night 2006 is not supported by or affiliated with Vivendi Universal Games, Sierra Online, or Papyrus Racing Games so please do not call or email them with problems.  If you find any issues with Iowa Speedway, e-mail mroyer1@comcast.net

==========================================================
Iowa Speedway Track Facts 
==========================================================
Track Size 7/8 mile Tri-Oval 
Track Width 60 Feet with 20 foot apron 
Banking 
 Turns 12-14 Degree Compound Banking 
 Front Stretch 10 Degrees 
 Back Stretch 4 Degrees 

==========================================================
Credits
==========================================================
Mark Royer (mroyer) - Design/Development
Carl Sundberg (ASTG-riveria) - general daily question/answer man
Chris O'Shell (ASTG-omodified) - AI, tons of general help
Dan Kaisinger (ti2blegrr) - lots and lots of at-track photos
Danny Coral (dcoral) - GNS and CUP sets
Wayne Faircloth (waynef) - CTS <fast> set
Landon Cassill (ASA-LM North Driver) - Real track vs sim track comparison 
Jim Foose (JimFoose) - fence, darker asphalt, safer barrier install, gate in T2
Chris Owens (gordonfan24) - trkshot.stp, parts of track.ini
HPCORS Drivers - several good tests of the beta track
Darell Watts (lastlap) - Safer Barriers mips
(dodge) - help with infield mips

==========================================================
Tools Used:
==========================================================
sandbox
3dsimed (Dave Noonan)
Winmip2
GIMP 2
Paint
Micrographx Picture Publisher


==========================================================
Version Descriptions
==========================================================
----------------------------------
v1.0 released 06-Dec-2006
     Release Version
----------------------------------
     Changes:
     Changed track.ini to reflect v1.0

     Fixed trees on horizon off T4 behind grandstand so they don't have sharp edge

     Moved people around in grandstands to more realistic seating arrangement

     Added People on top of VIP Building

     Added Dan Kaisinger hauler

     Softened first section of pitroad wall behind barrels to simulate barrels

     Removed <BullRingFixed> sets

     GNS, CTS and CUP AI completed

     Adjusted crowd sound locations

     Re-aligned infield 3dos off T3 and T4

     Darkened hospitality tent slightly

     changed GNS <fast> set to <expert>

     Re-did CUP sets

     Re-did GNS <fast> set

     Packed up Iowa.dat for release


----------------------------------
v0.8 released 17-Nov-2006
     AI In Process
----------------------------------
     Changes:
     Changed track.ini to reflect v0.8

     GNS AI nearly completed

     Reduced number of billboards in T3 to two

     Omodified redid billboards and scoring pylon mips completely

     Added 2nd Sunoco sign at end of pit concrete in T1/2
 
     deleted bogus <savefile> cup set

     Fixed s/f line to match real track

     sharpened tickets image in trklogo.stp

     Added white dashed paint lines on infield road along outer pit road wall

     Added barrels at wall on pitroad entry

     Brighten retainer fence posts

     Adjusted cams

     Adjusted RVs in T3


----------------------------------
v0.7 released 30-Oct-2006
     Release Candidate 3
----------------------------------
     Changes:
     Changed track.ini to reflect v0.7

     Fixed screwup naming CTS sets

     Fixed starter's box fence mips and lowered starter's box


----------------------------------
v0.6 released 27-Oct-2006
     Release Candidate 2
----------------------------------
     Changes:
     Changed track.ini to reflect v0.6

     Omodified improved water tower drawing.

     fixed sky angle so sun is in west (i.e., afternoon race to match fence shadow on track) 

     Retaining fence moved closer to safer barrier so it doesn't look as if floating in air

     Moved track caution lights to match new fence position

     Finally found and deleted the mystery blue tent (I had added and lost this 
     object in the very early days when I was learning to use sandbox.)

     fixed strange bitmapping of building off T4 (from certain angles it looked
     as if a bite had been taken out of the roof by a dinosaur.)

     Retainer fence is now properly curved matching the real track

     Added arcade.cts.acd, arcade.gns.acd and arcade.cup.acd that match sim mode setups

     renamed this readme file to Iowa_readme.txt

     Added trkinfo.stp and trkwin.stp (with USAR/Hooters ProCup banner) file

     Changed trklogo.stp to show Iowa HPC tickets (instead of logo)


----------------------------------
v0.5 released 20-Oct-2006
     Release Candidate
----------------------------------
     Changes:
     Changed track.ini to reflect v0.5

     fixed grass-asphalt edge on infield loop

     weathered the billboards

     Added light maps for fence on asphalt surface for West sun (i.e., afternoon race)

     broke infield mip into two pieces and fixed grass color (i.e., eliminated it from mip)

     matched infield mip colors to lightened asphalt colors and fixed grass color.

     Added more haulers to infield parking
     
     Added yellow and dashed white paint lines around small legends loop on infield

     Victory lane and HPC Soy Biodiesel 250 back board

     Checkered concrete around VIP building

     Added USAR Qual Whiteboard and crowd around it during practice

     moved pit road flag and paddle men down (they were floating in mid air)

     all chassis sets are properly credited in set notes

     draw-in problem of trees off turns largely fixed by bringing objects
     closer to track then shrinking them.  In rare cases, draw-in still 
     occurs - such as following a spin in T3/4 looking to T1/2 with the 
     far-chase cam.

     removed background image from sandbox and image mip file from Iowa folder


----------------------------------
v0.4 released 11-Oct-2006
----------------------------------
     Changes:
     Changed track.ini to reflect v0.4

     Added TSO 3do for farm silo off T2

     Improved resolution of horizon mip bitmaps

     Lightened asphalt mips (to show a bit of age)

     starting grid in track.ini for non-full pacelap completed

     Grandstand colors changed to blue/yellow scheme

     grandstand pieces near concession building added


----------------------------------
v0.3 released 30-Sep-2006
----------------------------------
     Changes:
     Changed track.ini to reflect v0.3

     Improved light pole spotlight mip bitmaps
     and fixed spotlight orientation with respect to the track.

     VIP Building front gets a facelift with clearer
     photographic imagery.

     Changed T2 billboards to closer form as per real track

     Adjusted pitch and roll of RVs

     Improved mip bitmap of blue water tower

     Got rid of magenta bleeding of tree3

     Gave tree2 and tree3 a bit of 3D effect

     Deleted a pile of extra, unused mips in trackmat folder
 
     Added TSO 3do for building off T2


----------------------------------
v0.2 released 22-Sep-2006
----------------------------------
     Changes:
     Changed track.ini to reflect v0.2

     Enlarged IOWASPEEDWAY.COM on backstretch safer barrier

     Enlarged IOWA SPEEDWAY on frontstretch safer barrier 
     and realigned it relative to starter box

     Deleted 'Iowa.txt' file and included info in this file below.

     Added new trkshot.stp and trklogo.stp (courtesy csubucs)

     Removed paint line along outside of road coarse on outside
     of pit lane.

     Extended pitlane outside wall further around T1 corner

     Added yellow dashed paint on pit lane all the way
     to pit exit line along asphalt section.

     Put IOWA1 through IOWA4 in T1 to T4

     The American flag now flaps.


----------------------------------
v0.1 released 20-Sep-2006
----------------------------------
     Changes:
     Changed track.ini to reflect v0.1

     fixed Mitran lighting in corners - the light poles were
     up in the air because when I dropped the apron banking 
     to below the front/back stretch apron level I forgot to
     also drop the light poles.

     Fixed up starter box - changed from red to yellow paint
     added weld-wire fencing like real Iowa starter box

     Put IOWASPEEDWAY.COM on backstretch safer barrier

     Put IOWA SPEEDWAY on front stretch safer barrier
     (this still needs to be better scaled)


----------------------------------
v0.0 released circa 16-Sep-2006
----------------------------------
     First release
     From this version forward, the version
     number (e.g., v0.0) appears in the 
     long track name (but not the short track name)
     and shows up in the single race menu and the
     event info menu.


----------------------------------
un-numbered versions
----------------------------------
		 a few un-numbered versions were released
		 to a couple leagues for beta test circa early
		 September.  These versions can be identified by noting
		 the track name in the single race menu.
		 There will be no version number as part of the name.

----------------------------------

